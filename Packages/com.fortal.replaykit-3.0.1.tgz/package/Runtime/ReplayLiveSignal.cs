using System;
using System.Globalization;
using System.IO;

namespace FortalReplay
{
    /// <summary>
    /// Only for games that keep their OWN log (EXISTING_LOG.md): writes &lt;log folder&gt;/_live.json so the OBS scripts
    /// know when a session starts and ends — the same signal ReplayLog.cs writes for games that use it (don't use both).
    /// Begin(gameName, logFile) when real play starts, End("completed" | "aborted") on the result screen / when leaving.
    /// gameName = the game's OBS scene name (ASCII). Schema: SPEC.md §2.
    /// </summary>
    public static class ReplayLiveSignal
    {
        static string game, session, logPath;

        public static bool Live { get; private set; }

        /// <param name="gameName">same name as the game's OBS scene (ASCII, no spaces needed)</param>
        /// <param name="logFile">path of the log file the game writes this session</param>
        public static void Begin(string gameName, string logFile)
        {
            game = gameName;
            session = game + "_" + DateTime.UtcNow.ToString("yyyyMMdd_HHmmss_fff", CultureInfo.InvariantCulture);
            logPath = logFile;
            Write("live", "");
            Live = true;
        }

        /// <param name="reason">"completed" (result screen) or "aborted" (left early)</param>
        public static void End(string reason)
        {
            if (!Live) return;
            Write("ended", reason);
            Live = false;
        }

        static string Esc(string s) => (s ?? "").Replace("\\", "/").Replace("\"", "'");

        static void Write(string state, string reason)
        {
            if (session == null || string.IsNullOrEmpty(logPath)) return;
            try
            {
                string full = Path.GetFullPath(logPath);
                string dir = Path.GetDirectoryName(full);
                Directory.CreateDirectory(dir);
                string json = "{\"state\":\"" + state + "\",\"game\":\"" + Esc(game) + "\",\"session\":\"" + Esc(session) +
                              "\",\"log\":\"" + Esc(full) + "\",\"reason\":\"" + Esc(reason) + "\",\"utc\":\"" +
                              DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture) + "\"}";
                string tmp = Path.Combine(dir, "_live.json.tmp");
                File.WriteAllText(tmp, json);                               // temp first, then replace,
                File.Copy(tmp, Path.Combine(dir, "_live.json"), true);      // so OBS never reads half a file
                File.Delete(tmp);
            }
            catch (Exception e)
            {
                UnityEngine.Debug.LogWarning("[ReplayLiveSignal] can't write _live.json: " + e.Message);
            }
        }
    }
}
