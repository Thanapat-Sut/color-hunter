# Fortal ReplayKit — Unity package 3.0.1

`using FortalReplay;` then call `ReplayLog.BeginSession` / `WriteFrame` / `EndSession` (+ optional `Event`).
Logs go to `<project>/ReplayLogs` in the Editor and `<build>/ReplayLogs` in a build.
Full guide: README.md in the ReplayKit (ขั้นที่ 1). Example: Package Manager → this package → Samples → Import.
