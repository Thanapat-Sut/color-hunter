using System.Collections.Generic;
using UnityEngine;
using FortalReplay;

/// <summary>
/// Minimal ReplayLog integration — copy the 4 calls into your own game manager.
/// Replace the placeholder fields (players, scores, phase) with your game's real state.
/// Only BeginSession / WriteFrame / EndSession are required; Event() is optional
/// (the cutter finds highlights from frames alone in no-context mode).
/// </summary>
public class ReplayExample : MonoBehaviour
{
    [SerializeField] string gameName = "MyGame";     // ASCII, no spaces: becomes the log file name
    [SerializeField] Transform[] players;            // your player objects
    [SerializeField] Vector2 floorMin = new Vector2(-5f, -5f), floorMax = new Vector2(5f, 5f);

    readonly List<ReplayPlayer> frame = new List<ReplayPlayer>(8);
    readonly ReplayLeadTracker lead = new ReplayLeadTracker();
    int[] scores;
    string phase = "Play";

    // 1) Call when real gameplay starts (after menus / countdown) — OBS starts recording here.
    public void StartMatch()
    {
        scores = new int[players.Length];
        lead.Reset();
        ReplayLog.BeginSession(gameName, players.Length, ReplayLog.Data().Add("rounds", 3));
    }

    // 2) Sample state ~10x per second.
    void Update()
    {
        if (!ReplayLog.ShouldSampleFrame()) return;
        frame.Clear();
        for (int i = 0; i < players.Length; i++)
        {
            bool tracked = players[i] != null && players[i].gameObject.activeInHierarchy;
            Vector3 p = tracked ? players[i].position : Vector3.zero;
            float x = Mathf.InverseLerp(floorMin.x, floorMax.x, p.x);   // 0 = left, 1 = right
            float y = Mathf.InverseLerp(floorMin.y, floorMax.y, p.z);   // 0 = near edge, 1 = far edge (wall)
            frame.Add(new ReplayPlayer(i, tracked, x, y, scores[i]));
        }
        ReplayLog.WriteFrame(phase, frame);
    }

    // 3) Optional: mark moments you already know are exciting.
    public void AddScore(int player, int points)
    {
        scores[player] += points;
        if (lead.Update(scores, out int leader, out int previous))
            ReplayLog.Event("lead_change", ReplayLog.TierA, 3f, 2f, leader,
                ReplayLog.Data().Add("previous", previous).Add("scores", scores));
    }

    // 4) Call on the result screen (completed) or when leaving early (aborted) — OBS stops ~4 s later and cuts.
    public void EndMatch(bool completed)
    {
        int[] winners = completed && lead.Leader >= 0 ? new[] { lead.Leader } : new int[0];   // empty = draw / none
        ReplayLog.EndSession(completed ? "completed" : "aborted", winners, scores);
    }

    void OnDisable() => ReplayLog.EndSession("unloaded");
}
